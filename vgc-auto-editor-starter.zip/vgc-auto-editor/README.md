# VGC Auto Editor — ElevenLabs V1

Starter pipeline, **not** the verified VGC Master Knowledge implementation. V1 generates a full voiceover from `input/script.txt`, replaces original audio, loops/crops source footage to fit voiceover, and optionally displays timed text from `input/timeline.json`. It does not auto-analyze footage, transcribe speech, or automatically sync captions to words.

## Setup
1. Private GitHub repository. Upload these files and folders (including hidden `.github`).
2. GitHub Settings → Secrets and variables → Actions → Secrets: add `ELEVENLABS_API_KEY` (never commit or paste the key in chat).
3. In the same Actions settings, **Variables**: add `ELEVENLABS_VOICE_ID` using your chosen voice's ID (not the API key).
4. Add your own `input/video.mp4` (short clip; GitHub web uploads are limited in size) and edit `input/script.txt`.
5. Edit or remove `input/timeline.json`. Times are seconds in the **generated narration**, not the original footage. The sample timestamps are placeholders: listen to the generated audio and adjust them before using for precise word sync. Remove the timeline file if you prefer no captions.
6. Actions → VGC Render → Run workflow. When completed, download `vgc-final-video` from the workflow run's Artifacts section.

## Important
- Private GitHub repository does not mean files are automatically uploaded from ChatGPT Mobile. V1 uses video committed to the repository; a separate authenticated upload bridge is needed for hands-free mobile uploads.
- Keep videos short: large video files should not be committed to Git long term. Later use private object storage and short-lived download URLs.
- The workflow consumes ElevenLabs credits. Run only on trusted code, protect repository write access, and do not log secrets.
- This example does not preserve original audio, auto-cut footage, or automatically produce accurate word-level captions. These are future modules.
- For official VGC method support, supply `VGC_MASTER_KNOWLEDGE.txt` separately and verify it before implementation.
