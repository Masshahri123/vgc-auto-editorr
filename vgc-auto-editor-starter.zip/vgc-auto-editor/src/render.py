import json, os, subprocess, urllib.request, pathlib, tempfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
VIDEO=ROOT/'input/video.mp4'; SCRIPT=ROOT/'input/script.txt'; OUT=ROOT/'output/vgc_final.mp4'

def run(*args): subprocess.run(args,check=True)
def duration(path):
    return float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(path)],text=True).strip())
def ass_time(t):
    h=int(t//3600);m=int(t%3600//60);s=t%60
    return f'{h}:{m:02}:{s:05.2f}'
def esc(s): return s.replace('\\',r'\\').replace('{',r'\{').replace('}',r'\}').replace('\n',r'\N')
def main():
    key=os.environ.get('ELEVENLABS_API_KEY'); voice=os.environ.get('ELEVENLABS_VOICE_ID')
    if not key or not voice: raise RuntimeError('Missing ELEVENLABS_API_KEY or ELEVENLABS_VOICE_ID')
    if not VIDEO.is_file() or not SCRIPT.is_file(): raise FileNotFoundError('Add input/video.mp4 and input/script.txt')
    text=SCRIPT.read_text(encoding='utf-8').strip()
    if not text: raise ValueError('script.txt is empty')
    OUT.parent.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        td=pathlib.Path(td); audio=td/'voice.mp3'
        payload=json.dumps({'text':text,'model_id':'eleven_multilingual_v2','voice_settings':{'stability':0.45,'similarity_boost':0.75}}).encode()
        req=urllib.request.Request('https://api.elevenlabs.io/v1/text-to-speech/'+voice, data=payload,headers={'xi-api-key':key,'Content-Type':'application/json','Accept':'audio/mpeg'},method='POST')
        with urllib.request.urlopen(req,timeout=120) as resp: audio.write_bytes(resp.read())
        length=duration(audio)
        if length<=0: raise ValueError('Invalid generated audio')
        timeline=ROOT/'input/timeline.json'; events=[]
        if timeline.exists():
            events=json.loads(timeline.read_text(encoding='utf-8'))
            if not isinstance(events,list): raise ValueError('timeline must be a list')
        ass=td/'captions.ass'
        lines=['[Script Info]','ScriptType: v4.00+','PlayResX: 1080','PlayResY: 1920','[V4+ Styles]','Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding','Style: Default,DejaVu Sans,76,&H00FFFFFF,&H0000FFFF,&H00000000,&H80000000,1,0,0,0,100,100,0,0,1,4,1,2,65,65,250,1','[Events]','Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text']
        for event in events:
            start=float(event['start']); end=float(event['end']); word=str(event['text'])
            if start<0 or end<=start or end>length+0.5: raise ValueError(f'Invalid timeline event: {event}')
            lines.append(f'Dialogue: 0,{ass_time(start)},{ass_time(min(end,length))},Default,,0,0,0,,{esc(word)}')
        ass.write_text('\n'.join(lines)+'\n',encoding='utf-8')
        vf='scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1'
        if events: vf+=f',ass={ass.as_posix()}'
        run('ffmpeg','-hide_banner','-loglevel','warning','-y','-stream_loop','-1','-i',str(VIDEO),'-i',str(audio),'-map','0:v:0','-map','1:a:0','-vf',vf,'-t',str(length),'-r','30','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart',str(OUT))
        print(f'Created {OUT} ({length:.1f}s)')
if __name__=='__main__': main()
